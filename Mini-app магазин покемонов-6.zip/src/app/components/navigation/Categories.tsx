import * as React from 'react';

interface CategoriesProps {
  activeCategory: string;
  onCategoryChange: (category: string) => void;
}

export function Categories({ activeCategory, onCategoryChange }: CategoriesProps) {
  const categories = [
    { id: 'cards', name: 'Карты', icon: '🃏' },
    { id: 'boosters', name: 'Бустер боксы', icon: '📦' },
    { id: 'contacts', name: 'Контакты', icon: '📞' },
    { id: 'sell', name: 'Продажа', icon: '💰' }
  ];

  return (
    <div style={{
      display: 'flex',
      justifyContent: 'space-around',
      alignItems: 'center',
      borderBottom: '1px solid #E2E8F0',
      padding: '8px 16px',
      position: 'sticky',
      top: '72px',
      zIndex: 40,
      backdropFilter: 'blur(8px)',
      background: 'rgba(255, 255, 255, 0.9)'  // ✅ ИСПРАВЛЕНО: вместо backgroundColor используем background
    }}>
      {categories.map(cat => (
        <button
          key={cat.id}
          onClick={() => onCategoryChange(cat.id)}
          style={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            gap: '4px',
            padding: '8px 12px',
            border: 'none',
            background: 'none',
            cursor: 'pointer',
            borderRadius: '12px',
            transition: 'all 0.2s',
            backgroundColor: activeCategory === cat.id ? '#F1F5F9' : 'transparent',
            color: activeCategory === cat.id ? '#0F172A' : '#64748B'
          }}
          onMouseEnter={(e) => {
            if (activeCategory !== cat.id) {
              e.currentTarget.style.backgroundColor = '#F8FAFC';
            }
          }}
          onMouseLeave={(e) => {
            if (activeCategory !== cat.id) {
              e.currentTarget.style.backgroundColor = 'transparent';
            }
          }}
        >
          <span style={{ fontSize: '20px' }}>{cat.icon}</span>
          <span style={{ 
            fontSize: '13px', 
            fontWeight: activeCategory === cat.id ? '600' : '500'
          }}>
            {cat.name}
          </span>
          {activeCategory === cat.id && (
            <div style={{
              width: '4px',
              height: '4px',
              backgroundColor: '#0F172A',
              borderRadius: '50%',
              marginTop: '2px'
            }} />
          )}
        </button>
      ))}
    </div>
  );
}