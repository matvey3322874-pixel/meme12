// src/app/components/card/CardPage.tsx
import * as React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useTheme } from '../theme/ThemeProvider';
import { MOCK_POKEMON_CARDS } from '../../../data/cards';

export function CardPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { colors } = useTheme();
  
  // Находим карту по ID
  const card = MOCK_POKEMON_CARDS.find(c => c.id === Number(id));
  
  if (!card) {
    return (
      <div style={{ padding: '40px', textAlign: 'center' }}>
        <h2>Карта не найдена</h2>
        <button onClick={() => navigate('/')}>Вернуться в каталог</button>
      </div>
    );
  }

  return (
    <div style={{ minHeight: '100vh', backgroundColor: colors.background }}>
      {/* Шапка */}
      <header style={{
        backgroundColor: colors.headerBg,
        color: 'white',
        padding: '12px 20px',
        position: 'sticky',
        top: 0,
        zIndex: 50
      }}>
        <div style={{ maxWidth: '1280px', margin: '0 auto', display: 'flex', alignItems: 'center', gap: '20px' }}>
          <button 
            onClick={() => navigate(-1)}
            style={{
              background: 'none',
              border: 'none',
              color: 'white',
              fontSize: '24px',
              cursor: 'pointer',
              padding: '4px 8px'
            }}
          >
            ←
          </button>
          <span style={{ fontSize: '20px', fontWeight: 'bold' }}>{card.name}</span>
        </div>
      </header>

      {/* Основной контент */}
      <main style={{ maxWidth: '1200px', margin: '0 auto', padding: '40px 20px' }}>
        <div style={{
          display: 'grid',
          gridTemplateColumns: '1fr 1fr',
          gap: '40px',
          backgroundColor: colors.cardBg,
          borderRadius: '24px',
          padding: '40px',
          boxShadow: '0 20px 40px rgba(0,0,0,0.1)'
        }}>
          {/* Левая колонка - изображение */}
          <div style={{
            backgroundColor: '#FFFFFF',
            borderRadius: '20px',
            padding: '40px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            aspectRatio: '1/1'
          }}>
            <img 
              src={card.image || 'https://via.placeholder.com/400'} 
              alt={card.name}
              style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain' }}
            />
          </div>

          {/* Правая колонка - информация */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
            <div>
              <h1 style={{ fontSize: '32px', fontWeight: '800', color: colors.text, marginBottom: '8px' }}>
                {card.name}
              </h1>
              <div style={{
                display: 'inline-block',
                padding: '6px 12px',
                backgroundColor: colors.filterBg,
                color: colors.accent,
                borderRadius: '20px',
                fontSize: '14px',
                fontWeight: '600'
              }}>
                {card.rarity}
              </div>
            </div>

            <div style={{ height: '2px', backgroundColor: colors.border }} />

            <div>
              <div style={{ fontSize: '14px', color: colors.textSecondary, marginBottom: '4px' }}>Цена</div>
              <div style={{ fontSize: '48px', fontWeight: '800', color: colors.text }}>
                {card.price.toLocaleString()} ₽
              </div>
            </div>

            <div>
              <div style={{ fontSize: '14px', color: colors.textSecondary, marginBottom: '8px' }}>Наличие</div>
              <div style={{
                display: 'inline-block',
                padding: '8px 16px',
                backgroundColor: card.id % 3 === 0 ? '#FEE2E2' : '#E6F7E6',
                color: card.id % 3 === 0 ? '#EF4444' : '#10B981',
                borderRadius: '30px',
                fontSize: '16px',
                fontWeight: '600'
              }}>
                {card.id % 3 === 0 ? 'Нет в наличии' : 'В наличии 10 шт'}
              </div>
            </div>

            <div style={{ marginTop: '20px' }}>
              <button style={{
                width: '100%',
                padding: '16px',
                backgroundColor: colors.buttonBg,
                color: colors.buttonText,
                border: 'none',
                borderRadius: '12px',
                fontSize: '18px',
                fontWeight: '600',
                cursor: card.id % 3 === 0 ? 'not-allowed' : 'pointer',
                opacity: card.id % 3 === 0 ? 0.5 : 1
              }}>
                {card.id % 3 === 0 ? 'Нет в наличии' : 'Добавить в корзину'}
              </button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}