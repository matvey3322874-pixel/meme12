import * as React from 'react';
import { useState, useEffect, useRef } from 'react';
import { useTheme } from '../theme/ThemeProvider';
import { usePokemonSearch } from '../../hooks/usePokemonSearch';  // ← путь правильный!
import { SearchSuggestions } from './SearchSuggestions';

interface SearchBarProps {
  onSearch?: (query: string) => void;
  onPokemonSelect?: (pokemon: any) => void;
  placeholder?: string;
}

export function SearchBar({ onSearch, onPokemonSelect, placeholder = 'Поиск карт...' }: SearchBarProps) {
  const { colors } = useTheme();  // ← useTheme, а не useState!
  const { query, setQuery, suggestions, setSelectedPokemon, clearSearch } = usePokemonSearch();
  const [isFocused, setIsFocused] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);

  // Закрытие подсказок при клике вне
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsFocused(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSelectPokemon = (pokemon: any) => {
    setSelectedPokemon(pokemon);
    setQuery(pokemon.name.ru);
    setIsFocused(false);
    if (onPokemonSelect) onPokemonSelect(pokemon);
    if (onSearch) onSearch(pokemon.name.ru);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (onSearch) onSearch(query);
  };

  return (
    <div ref={searchRef} style={{ position: 'relative', flex: 1 }}>
      <form onSubmit={handleSearch}>
        <div style={{ position: 'relative' }}>
          <span style={{
            position: 'absolute',
            left: '12px',
            top: '50%',
            transform: 'translateY(-50%)',
            color: colors?.textSecondary || '#64748B',
            zIndex: 1
          }}>🔍</span>
          
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onFocus={() => setIsFocused(true)}
            placeholder={placeholder}
            style={{
              width: '100%',
              padding: '12px 40px',
              border: `1px solid ${isFocused ? (colors?.accent || '#3B82F6') : (colors?.border || '#E2E8F0')}`,
              borderRadius: '12px',
              fontSize: '15px',
              outline: 'none',
              backgroundColor: colors?.cardBg || 'white',
              color: colors?.text || '#0F172A',
              boxSizing: 'border-box',
              transition: 'all 0.2s'
            }}
          />
          
          {query && (
            <button
              type="button"
              onClick={clearSearch}
              style={{
                position: 'absolute',
                right: '12px',
                top: '50%',
                transform: 'translateY(-50%)',
                background: 'none',
                border: 'none',
                cursor: 'pointer',
                color: colors?.textSecondary || '#64748B',
                fontSize: '16px'
              }}
            >
              ✕
            </button>
          )}
        </div>
      </form>

      <SearchSuggestions
        suggestions={suggestions}
        onSelect={handleSelectPokemon}
        visible={isFocused && suggestions.length > 0}
      />
    </div>
  );
}