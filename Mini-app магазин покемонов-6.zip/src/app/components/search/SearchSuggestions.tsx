import * as React from 'react';
import { Pokemon } from '../../data/pokemonDatabase';
import { useTheme } from '../theme/ThemeProvider';

interface SearchSuggestionsProps {
  suggestions: Pokemon[];
  onSelect: (pokemon: Pokemon) => void;
  visible: boolean;
}

export function SearchSuggestions({ suggestions, onSelect, visible }: SearchSuggestionsProps) {
  const { colors } = useTheme();
  
  if (!visible || suggestions.length === 0) return null;

  return (
    <div style={{
      position: 'absolute',
      top: '100%',
      left: 0,
      right: 0,
      backgroundColor: colors.cardBg,
      border: `1px solid ${colors.border}`,
      borderRadius: '12px',
      marginTop: '4px',
      maxHeight: '300px',
      overflowY: 'auto',
      zIndex: 1000,
      boxShadow: '0 4px 12px rgba(0,0,0,0.15)'
    }}>
      {suggestions.map((pokemon) => (
        <button
          key={pokemon.id}
          onClick={() => onSelect(pokemon)}
          style={{
            width: '100%',
            padding: '10px 16px',
            display: 'flex',
            alignItems: 'center',
            gap: '12px',
            border: 'none',
            backgroundColor: 'transparent',
            cursor: 'pointer',
            color: colors.text,
            borderBottom: `1px solid ${colors.border}`,
            transition: 'background-color 0.2s'
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.backgroundColor = colors.filterBg;
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.backgroundColor = 'transparent';
          }}
        >
          {/* Иконка покемона (Pokemon Home style) */}
          <img 
            src={pokemon.image} 
            alt={pokemon.name.en}
            style={{
              width: '32px',
              height: '32px',
              objectFit: 'contain'
            }}
            onError={(e) => {
              e.currentTarget.src = 'https://via.placeholder.com/32';
            }}
          />
          
          {/* Информация о покемоне */}
          <div style={{ flex: 1, textAlign: 'left' }}>
            <div style={{ fontWeight: '600' }}>
              {pokemon.name.ru}
            </div>
            <div style={{ fontSize: '12px', color: colors.textSecondary }}>
              #{pokemon.id.toString().padStart(3, '0')} • {pokemon.name.en}
            </div>
          </div>
          
          {/* Типы покемона */}
          <div style={{ display: 'flex', gap: '4px' }}>
            {pokemon.types.map(type => (
              <span key={type} style={{
                fontSize: '10px',
                padding: '2px 6px',
                borderRadius: '10px',
                backgroundColor: colors.accent,
                color: 'white',
                opacity: 0.8
              }}>
                {type}
              </span>
            ))}
          </div>
        </button>
      ))}
    </div>
  );
}